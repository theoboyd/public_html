package util;

import java.util.LinkedList;
import java.util.List;

import strategy.AEGS;
import strategy.AEGSS;
import strategy.AlwaysCooperates;
import strategy.AlwaysDefects;
import strategy.AlwaysRandom;
import strategy.Bayesian;
import strategy.NashTitForTat;
import strategy.NegativePeople;
import strategy.NonsensePeople;
import strategy.PositivePeople;
import strategy.SocialTitForTat;
import strategy.Strategy;
import strategy.TitForTat;

/**
 * Wrapper collection for all valid, supported strategies
 */
public class StrategyCollection {
  List<Strategy> strategies;

  public StrategyCollection() {
    strategies = new LinkedList<Strategy>();
    strategies.add(new AEGS());
    strategies.add(new AEGSS());
    strategies.add(new AlwaysCooperates());
    strategies.add(new AlwaysDefects());
    strategies.add(new AlwaysRandom());
    strategies.add(new Bayesian());
    strategies.add(new NashTitForTat());
    strategies.add(new NegativePeople());
    strategies.add(new NonsensePeople());
    strategies.add(new PositivePeople());
    strategies.add(new SocialTitForTat());
    strategies.add(new TitForTat());
    // strategies.add(new TestStrategy());
  }

  public List<Strategy> getStrategies() {
    return strategies;
  }

  public Strategy getSocialWinner() {
    Strategy winner = strategies.get(0);
    for (Strategy s : strategies) {
      if (s.getSocialScore() > winner.getSocialScore()) {
        winner = s;
      }
    }
    return winner;
  }

  public Strategy getMaterialWinner() {
    Strategy winner = strategies.get(0);
    for (Strategy s : strategies) {
      if (s.getMaterialScore() > winner.getMaterialScore()) {
        winner = s;
      }
    }
    return winner;
  }
}