package util;

public class StrategyException extends Exception {

  private static final long serialVersionUID = 479553774096920137L;

  public StrategyException(String message) {
    super(message);
  }
}
